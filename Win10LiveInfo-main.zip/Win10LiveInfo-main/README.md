# Windows 10 Live Information viewer 

Gather Information from a running Windows 10 Workstation, collected via [CIM](https://docs.microsoft.com/en-us/windows/win32/wmisdk/common-information-model) or the Registry<br> 

![WinLiveInfo Screen](https://raw.githubusercontent.com/kacos2000/Win10LiveInfo/main/WinLiveInfo118.jpg)

